// Défintion d'un parametrage par défaut
var param = {
    auteur : 'Marc levy',
    titre : 'vrai'
}
run(param);


// Fonction d'écriture des divs
function append(livre) {
    titre = livre.titre;
    content = livre.description;
    img = livre.image;
    
    //content = content.substring(0, 100)+" ...";
    
    // build/select our elements
    var grid = $('#columns')[0];
    var item = document.createElement('div');
    // build the html
    var h = '<div class="panel panel-primary">';
    h += '<div class="panel-heading">';
    h += titre;
    h += '</div>';
    h += '<div class="panel-body">';
    h += '<img src="'+img+'" class="img-responsive"/>';
    h += content;
    h += '</div>';
    h += '</div>';
    salvattore['append_elements'](grid, [item]);
    item.outerHTML = h;
}

// Fonction d'écriture des divs
function run(param){
    //Déclarer les variables criterias (liste des items de recherche) et criteriaStr (chaine de caractere)
    var criterias = new Array();
    var criteriaStr = "";
    
    
    if(param.titre !== ""){
        criterias.push(encodeURIComponent(param.titre));
    }
    if(param.auteur !== ""){
        criterias.push('inauthor:'+encodeURIComponent(param.auteur));
    }
    
    // Ecriture de la chaine de recherche
    for(var i= 0; i < criterias.length; i++){
        if(i === criterias.length-1){criteriaStr += criterias[i];
        }else{criteriaStr += criterias[i]+"&"; }
    }
    
    // ADRESSE DU JSON
    var url = "https://www.googleapis.com/books/v1/volumes?q="+criteriaStr+"&maxResults:40";
   
    /*
     * Ecriture de toutes les parties unique (non boucle d'item)
     */
    $('#authorSearched h2').remove(); //Effacer l'existant
    $('#authorSearched').append('<h2>'+url+'</h2>'); //Reecrire le titre
    $('#columns div div').remove(); // Effacer les divs de la liste
 
    /**
     * On récupère le json
     * Création d'un objet générique avec les items à lire
     */
    $.getJSON(url, function (data) {
        console.log(data);
        $(data.items).each(function (i, book) {
            var livre = {
                titre       : book.volumeInfo.title,
                description : book.volumeInfo.description,
                image       : book.volumeInfo.imageLinks.smallThumbnail
            };
            // Pour chaque Item : écriture d'un div
            append(livre);
        });
    });
}

// Au click sur le bouton de recherche

$('#search').click(function() {
    var auteur = $('#auteur').val();
    var titre = $('#titre').val();
   
    var param =  {
        auteur : auteur,
        titre  : titre
    };
 
    run(param);
    return false;
});

