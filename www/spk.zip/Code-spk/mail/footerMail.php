    
<div style='text-align: center'>
    <p>Tous droits r&eacute;s&eacute;rv&eacute;s -  Spibook - Vivez les &eacute;v&eacute;nements qui vous ressemblent</p>
    <p><a href='http://www.spibook.com/'>www.spibook.com</a></p>
</div>
</body>
</html>