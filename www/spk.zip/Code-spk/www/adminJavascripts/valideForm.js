//$.validator.setDefaults({
//	submitHandler: function() { alert("submitted!"); }
//});
//
//
//$().ready(function() {
//   jQuery("#signaletique").validate({
//      rules: {
//         
//         "nom": {
//            "required": true
//         }
//  }})
//});
