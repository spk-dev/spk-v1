<div class="twelve">
    
    <div class="four columns">
        <div class="fb-share-button" data-href="<?php echo Redirect::getCurrentUrl(); ?>" data-type="button_count"></div></div>
  
    <div class="four columns">
        <a href="https://twitter.com/share" class="twitter-share-button" data-lang="en">Tweet</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
    </div>
    
    <div class="four columns">
        <!-- Placez cette balise où vous souhaitez faire apparaître le gadget bouton "Partager". -->
<div class="g-plus" data-action="share" data-annotation="bubble"></div>

<!-- Placez cette ballise après la dernière balise Partager. -->
<script type="text/javascript">
  window.___gcfg = {lang: 'fr'};

  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/platform.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>
        
    </div>
        
        
</div>

