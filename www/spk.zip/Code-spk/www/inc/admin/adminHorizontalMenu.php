<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


?>

<div class="nav">
    <div class="table">

        <ul class="select">
            <li><a href="#nogo"><b>Dashboard</b><!--[if IE 7]><!--></a><!--<![endif]-->
            <!--[if lte IE 6]><table><tr><td><![endif]-->
            <div class="select_sub">
                    <ul class="sub">
                            <li><a href="#nogo">Dashboard Details 1</a></li>
                            <li><a href="#nogo">Dashboard Details 2</a></li>
                            <li><a href="#nogo">Dashboard Details 3</a></li>
                    </ul>
            </div>
            <!--[if lte IE 6]></td></tr></table></a><![endif]-->
            </li>
        </ul>

        <div class="nav-divider">&nbsp;</div>

        <ul class="current"><li><a href="#nogo"><b>Products</b><!--[if IE 7]><!--></a><!--<![endif]-->
            <!--[if lte IE 6]><table><tr><td><![endif]-->
            <div class="select_sub show">
                    <ul class="sub">
                            <li><a href="#nogo">View all products</a></li>
                            <li class="sub_show"><a href="#nogo">Add product</a></li>
                            <li><a href="#nogo">Delete products</a></li>
                    </ul>
            </div>
            <!--[if lte IE 6]></td></tr></table></a><![endif]-->
            </li>
        </ul>

        <div class="nav-divider">&nbsp;</div>

        <ul class="select"><li><a href="#nogo"><b>Categories</b><!--[if IE 7]><!--></a><!--<![endif]-->
            <!--[if lte IE 6]><table><tr><td><![endif]-->
            <div class="select_sub">
                    <ul class="sub">
                            <li><a href="#nogo">Categories Details 1</a></li>
                            <li><a href="#nogo">Categories Details 2</a></li>
                            <li><a href="#nogo">Categories Details 3</a></li>
                    </ul>
            </div>
            <!--[if lte IE 6]></td></tr></table></a><![endif]-->
            </li>
        </ul>

        <div class="nav-divider">&nbsp;</div>

        <ul class="select"><li><a href="#nogo"><b>Clients</b><!--[if IE 7]><!--></a><!--<![endif]-->
            <!--[if lte IE 6]><table><tr><td><![endif]-->
            <div class="select_sub">
                    <ul class="sub">
                            <li><a href="#nogo">Clients Details 1</a></li>
                            <li><a href="#nogo">Clients Details 2</a></li>
                            <li><a href="#nogo">Clients Details 3</a></li>

                    </ul>
            </div>
            <!--[if lte IE 6]></td></tr></table></a><![endif]-->
            </li>
        </ul>

        <div class="nav-divider">&nbsp;</div>

        <ul class="select"><li><a href="#nogo"><b>News</b><!--[if IE 7]><!--></a><!--<![endif]-->
            <!--[if lte IE 6]><table><tr><td><![endif]-->
            <div class="select_sub">
                    <ul class="sub">
                            <li><a href="#nogo">News details 1</a></li>
                            <li><a href="#nogo">News details 2</a></li>
                            <li><a href="#nogo">News details 3</a></li>
                    </ul>
            </div>
            <!--[if lte IE 6]></td></tr></table></a><![endif]-->
            </li>
        </ul>

        <div class="clear"></div>
    </div>
		<div class="clear"></div>
</div>