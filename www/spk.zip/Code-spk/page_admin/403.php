<div class="row">
    
    <div class="twelve columns">
        
        <div class="six columns panel centered">
            
            <h1>ERREUR 403</h1>
            
            <h1 class="small">Accés non autorisé.</h1>
            <br/>
            <ul>
                <li><a href="javascript:history.back()">Retour à la page précédente.</a></li>
            
                <li><a href="<?php echo $_ENV['properties']['Page']['defaultAdmin']; ?>">Retour au tableau de bord.</a></li>
            </ul>
        </div>
        
    </div>
    
</div>
<div class="row">&nbsp;</div>