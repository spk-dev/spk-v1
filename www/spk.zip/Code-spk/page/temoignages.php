<div class="row">
    <div class="twelve columns">
      <!-- Feed Entry -->
     <div class="row">
         <div class="two columns mobile-one"><a name="NorbertTurini"></a><img src="images/data/Blog/MgrNorbertTurini.jpg"/></div>
        <div class="ten columns">
          <p>
              <strong>Mgr Norbert Turini, évêque de Cahors </strong><br/>Le 29 mai 2013<br/>
          <blockquote class="JustifyText">  « Où trouver, sans trop avoir à chercher, un événement ou un lieu de ressourcement spirituel ?
            SPIBOOK.<br/>
            Il s’agit d’un site, facile d’accès et d’utilisation. J’y ai découvert  un véritable guide pour aider l’internaute à trouver l’événement religieux ou la retraite spirituelle qui correspond à sa recherche.<br/>
            Dès lors vous êtes orienté vers le monastère, le sanctuaire, le haut-lieu spirituel qui répond le mieux à votre attente. On gagne du temps et surtout l’on peut y trouver la « perle spirituelle » dans le champ du monde : le Dieu de Jésus-Christ <br/>
          <dd><dl>qui transfigure toute existence quand on l’a rencontré,</dl>
              <dl>qui change nos déserts intérieurs en terres d’éternels printemps,</dl>
              <dl>qui nous fait toujours avancer dans le sens de la Vie. »</dl>
 </dd></blockquote>
<p class="rightText">+Norbert TURINI</p>

          
          
          
      </div>
      <!-- End Feed Entry -->
      
      <hr />
      
      <!-- End Feed Entry -->
      
    </div>
</div>
</div>