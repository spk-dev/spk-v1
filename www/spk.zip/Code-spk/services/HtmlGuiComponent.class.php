<?php

/**
 * 
 */
class HtmlGuiComponent{
    
    
}

?>
